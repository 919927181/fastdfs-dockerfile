
this network service framework library extract from FastDFS
